Udacity's cloud developer degree first project submission.

S3 Bucket Url: http://static-site-udacity-2022-08-15.s3-website-us-east-1.amazonaws.com/
CloudFront Distribution Url: https://d1ld15fy76ienh.cloudfront.net/


steps to get site up and running:

1. Create S3 Bucket.
2. Added Access Policy to The Bucket.
3. Configure S3 bucket for Static Site Hosting.
4. Create CloudFront Distribution.
5. Configure CloudFront Distribution to Use S3 Bucket.
6. Test and View Site in Browser

Created by:
    Ahmed Shawkat Helmi